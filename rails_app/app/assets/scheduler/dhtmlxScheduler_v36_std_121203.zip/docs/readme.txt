You can access the online documentation at 
	http://docs.dhtmlx.com/doku.php?id=dhtmlxscheduler:toc

Also, you can grab offline version by the next links

	CHM version
		http://dhtmlx.com/x/download/regular/dhtmlxScheduler_docs_chm.zip
	HTML version
		http://dhtmlx.com/x/download/regular/dhtmlxScheduler_docs_html.zip
